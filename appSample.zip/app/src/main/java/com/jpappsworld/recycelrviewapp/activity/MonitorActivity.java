package com.jpappsworld.recycelrviewapp.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.jpappsworld.recycelrviewapp.R;
import com.jpappsworld.recycelrviewapp.adapter.AndroidAdapter;
import com.jpappsworld.recycelrviewapp.adapter.MonitorAdapter;
import com.jpappsworld.recycelrviewapp.domain.Monitors;
import com.jpappsworld.recycelrviewapp.domain.Versions;

import java.util.ArrayList;
import java.util.List;

public class MonitorActivity extends AppCompatActivity {

    private RecyclerView rvMonitors;
    private MonitorAdapter adapter;
    private LinearLayoutManager linearLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_monitor);
        initializeViews();
        setAdapter(getAllMonitors());
    }

    private void initializeViews() {
        rvMonitors = findViewById(R.id.rv_monitors);
        rvMonitors.setHasFixedSize(true);
        linearLayoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        rvMonitors.setLayoutManager(linearLayoutManager);

    }

    private void setAdapter(List<Monitors> monitorsList){
        adapter = new MonitorAdapter(monitorsList);
        rvMonitors.setAdapter(adapter);
    }

    private List<Monitors> getAllMonitors() {
        List<Monitors> monitorsList = new ArrayList<>();
        monitorsList.add(new Monitors("HP Z32x", "CN000001", R.drawable.icon_colorcalibration));
        monitorsList.add(new Monitors("HP Engage", "CN000002", R.drawable.icon_colorcalibration));
        monitorsList.add(new Monitors("Z24iG4", "CN000003", R.drawable.icon_colorcalibration));
        monitorsList.add(new Monitors("Z27FG3", "CN000004", R.drawable.icon_colorcalibration));
        return monitorsList;
    }
}