package com.jpappsworld.recycelrviewapp.domain;

public class Versions {

    public String getVersionName() {
        return versionName;
    }

    public void setVersionName(String versionName) {
        this.versionName = versionName;
    }

    private String versionName;
}
